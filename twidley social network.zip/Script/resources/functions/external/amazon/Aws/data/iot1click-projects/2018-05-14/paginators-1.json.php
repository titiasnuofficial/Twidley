<?php
// This file was auto-generated from sdk-root/src/data/iot1click-projects/2018-05-14/paginators-1.json
return [ 'pagination' => [],];
