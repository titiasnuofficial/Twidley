<?php
// This file was auto-generated from sdk-root/src/data/endpoints_prefix_history.json
return [ 'prefix-groups' => [ 'api.sagemaker' => [ 'sagemaker', ], 'sagemaker' => [ 'api.sagemaker', ], ],];
