<?php

// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+
$classUser = new User();
if (isset($_POST) && !empty($_POST)) {
    if ($classUser->So_UpdateUser($so['user']['user_id'], array('about' => $_POST['about']))) {
        $data = array(
            'status' => 200
        );
    } else {
        $data = array(
            'status' => 400
        );
    }
} else {
    $data = array(
        'status' => 400,
        'errors' => $so['lang']['check_details']
    );
}

header("Content-type: application/json");
echo json_encode($data);
exit();
?>