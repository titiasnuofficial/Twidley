<?php

/* 
 * ** +------------------------------------------------------------------------+**
 * ** | @author Titiasnu Official (titiasnu_official)**
 * ** | @author_url 1: https://www.twidley.com**
 * ** | @author_url 2: titiasnu1@gmail.com**
 * ** +------------------------------------------------------------------------+**
 * ** | Twidley - The Pro Social Network**
 * ** | Copyright (c) 2018 Twidley. All rights reserved.**
 * ** +------------------------------------------------------------------------+**
 */
if (isset($_SESSION['night_mode']) && $_SESSION['night_mode'] == 1) {
    $_SESSION['night_mode'] = 0;
} else {
    $_SESSION['night_mode'] = 1;
}
header("Content-type: application/json");
echo json_encode(array('status' => 200));
exit();
