<?php
$so['description'] = $so['lang']['site_description'];
$so['keywords']    = $so['lang']['site_keywords'];
$so['page']        = 'about';
$so['title']       = $so['lang']['terms_about'];
$so['content']     = So_GetPage('footer/terms-about');