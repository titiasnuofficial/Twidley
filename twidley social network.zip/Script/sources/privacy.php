<?php
$so['description'] = $so['lang']['site_description'];
$so['keywords']    = $so['lang']['site_keywords'];
$so['page']        = 'privacy';
$so['title']       = $so['lang']['terms_privacy'];
$so['content']     = So_GetPage('footer/terms-privacy');