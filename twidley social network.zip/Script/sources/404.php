<?php
$so['description'] = $so['lang']['site_description'];
$so['keywords']    = $so['lang']['site_keywords'];
$so['page']        = '404';
$so['title']       = $so['lang']['error_404_not_found'];
$so['content']     = So_GetPage('404/content');