<?php

// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+


require_once('./resources/init.php');

$query = mysqli_query($sqlConnect, "SELECT `user_id` FROM " . T_USERS . " ORDER BY `user_id` DESC LIMIT 1");
$assoc = mysqli_fetch_assoc($query);
$update = mysqli_query($sqlConnect, "UPDATE " . T_USERS . " SET `admin` = '1' WHERE `user_id` = '{$assoc['user_id']}'");

if ($update) {
	echo 'Done, delete file update.php';
} else {
	echo 'error, contact the developer';
}
?>