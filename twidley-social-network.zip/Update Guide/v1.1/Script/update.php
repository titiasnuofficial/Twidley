<?php

// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+


require_once('./resources/init.php');

$update = mysqli_query($sqlConnect, "UPDATE " . T_CONFIG . " SET `value` = 'twidley' WHERE `name` = 'theme'");

if ($update) {
	echo 'Done, delete file update.php';
} else {
	echo 'error, contact the developer';
}
?>