<?php

require_once('boot.php');

function So_TotalUsers() {
    global $so, $sqlConnect;
    if ($so['loggedin'] === false || $so['user']['admin'] < 1) {
        return false;
    }

    $select = "SELECT `user_id` FROM " . T_USERS;
    $query = mysqli_query($sqlConnect, $select);

    return mysqli_num_rows($query);
}

function So_TotalPosts() {
    global $so, $sqlConnect;
    if ($so['loggedin'] === false || $so['user']['admin'] < 1) {
        return false;
    }

    $select = "SELECT `post_id` FROM " . T_POSTS;
    $query = mysqli_query($sqlConnect, $select);

    return mysqli_num_rows($query);
}

function So_GetUsers() {
    global $so, $sqlConnect;
    if ($so['loggedin'] === false || $so['user']['admin'] < 1) {
        return false;
    }

    $data = array();

    $select = "SELECT `user_id` FROM " . T_USERS . " ORDER BY `user_id` LIMIT 100";
    $query = mysqli_query($sqlConnect, $select);
    $classUser = new User();
    while ($assoc = mysqli_fetch_assoc($query)) {
        $data[] = $classUser->So_UserData($assoc['user_id']);
    }

    return $data;
}

function So_GetConfigAdmin() {
    global $so, $sqlConnect;
    if ($so['loggedin'] === false || $so['user']['admin'] < 1) {
        return false;
    }

    $data = array();

    $select = "SELECT * FROM " . T_CONFIG;
    $query = mysqli_query($sqlConnect, $select);
    while ($assoc = mysqli_fetch_assoc($query)) {
        $data[] = $assoc;
    }

    return $data;
}

function So_SaveConfig($name, $value) {
    global $so, $sqlConnect;
    if ($so['loggedin'] === false || $so['user']['admin'] < 1) {
        return false;
    }

    $name = So_Secure($name);
    $value = So_Secure($value);

    $update = mysqli_query($sqlConnect, "UPDATE " . T_CONFIG . " SET `value` = '{$value}' WHERE `name` = '{$name}'");
    if ($update) {
        return true;
    } else {
        return false;
    }
}

function So_DecodeBr2nl($st) {
    $breaks = array(
        "\r\n",
        "\r",
        "\n"
    );
    $st = str_replace($breaks, "", $st);
    $st_no_lb = preg_replace("/\r|\n/", "", $st);
    return preg_replace('/<br(\s+)?\/?>/i', "\r", $st_no_lb);
}

function So_GeoData() {
    $user_ip = getenv('REMOTE_ADDR');
    $geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));

    $data = array(
        'country' => $geo["geoplugin_countryName"],
        'timezone' => $geo["geoplugin_timezone"]
    );

    return $data;
}

?>