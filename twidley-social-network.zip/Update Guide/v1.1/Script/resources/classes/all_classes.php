<?php
// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+
require_once('user/user.php');
require_once('upload/upload.php');
require_once('post/post.php');
require_once('emoticon/emoticon.php');
require_once('comment/comment.php');
require_once('message/message.php');
?>