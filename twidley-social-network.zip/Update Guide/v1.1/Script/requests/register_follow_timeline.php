<?php

/* 
 * ** +------------------------------------------------------------------------+**
 * ** | @author Titiasnu Official (titiasnu_official)**
 * ** | @author_url 1: https://www.twidley.com**
 * ** | @author_url 2: titiasnu1@gmail.com**
 * ** +------------------------------------------------------------------------+**
 * ** | Twidley - The Pro Social Network**
 * ** | Copyright (c) 2018 Twidley. All rights reserved.**
 * ** +------------------------------------------------------------------------+**
 */
$classUser = new User();
if (isset($_GET['user'])) {
    $user_id = So_Secure($_GET['user']);
    
    if ($classUser->So_RegisterFollow($user_id) === true) {
        $so['profile'] = $classUser->So_UserData($user_id);
        $html = So_GetPage('buttons/button-timeline-follow');
        
        $data = array(
            'status' => 200,
            'html' => $html
        );
    } else {
        $data = array(
            'status' => 400
        );
    }
    
} else {
    $data = array(
        'status' => 400
    );
}
header("Content-type: application/json");
echo json_encode($data);
exit();

