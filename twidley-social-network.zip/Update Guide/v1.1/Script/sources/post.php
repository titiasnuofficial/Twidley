<?php

if ($so['loggedin'] === false || !isset($_GET['post_id'])) {
    header("Location: " . So_SeoLink('index.php?link1=welcome'));
    exit();
}

$classPost = new Post();
$so['story'] = $classPost->So_PostData(So_Secure($_GET['post_id']));

$so['description'] = $so['lang']['site_description'];
$so['keywords'] = $so['lang']['site_keywords'];
$so['page'] = 'post';
$so['title'] = $so['config']['site_name'];
if (count($classPost->So_PostData(So_Secure($_GET['post_id']))) < 1) {
    $so['content'] = So_GetPage('404/content');
} else {
    $so['content'] = So_GetPage('story/content-notification');
}
