<?php

// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+
$classPost = new Post();
$posts = $classPost->So_GetPosts();
if (count($posts) > 0) {
	
	$html = '';
	
	foreach ($posts as $so['story']) {
		$html .= So_GetPage('story/content');
	}
	$data = array('status' => 200, 'html' => $html);
} else {
	$data = array('status' => 400);
}

header("Content-type: application/json");
echo json_encode($data);
exit();
?>