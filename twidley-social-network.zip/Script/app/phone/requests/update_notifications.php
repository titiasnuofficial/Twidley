<?php

/* 
 * ** +------------------------------------------------------------------------+**
 * ** | @author Titiasnu Official (titiasnu_official)**
 * ** | @author_url 1: https://www.twidley.com**
 * ** | @author_url 2: titiasnu1@gmail.com**
 * ** +------------------------------------------------------------------------+**
 * ** | Twidley - The Pro Social Network**
 * ** | Copyright (c) 2018 Twidley. All rights reserved.**
 * ** +------------------------------------------------------------------------+**
 */

$query = mysqli_query($Connect, "UPDATE " . T_NOTIFICATIONS . " SET `seen` = '1' WHERE `to_id` = '{$so['user']['user_id']}' AND `seen` = '0'");

if ($query) {
    $data = array('status' => 200);
} else {
    $data = array('status' => 400);
}

header("Content-type: application/json");
echo json_encode($data);
exit();