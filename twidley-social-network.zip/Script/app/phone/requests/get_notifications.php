<?php

/* 
 * ** +------------------------------------------------------------------------+**
 * ** | @author Titiasnu Official (titiasnu_official)**
 * ** | @author_url 1: https://www.twidley.com**
 * ** | @author_url 2: titiasnu1@gmail.com**
 * ** +------------------------------------------------------------------------+**
 * ** | Twidley - The Pro Social Network**
 * ** | Copyright (c) 2018 Twidley. All rights reserved.**
 * ** +------------------------------------------------------------------------+**
 */
$notifications = So_NotificationAppGet($_GET['user_id']);

$data = array(
	'data' => $notifications
);

$query = mysqli_query($Connect, "UPDATE " . T_NOTIFICATIONS . " SET `seen` = '1' WHERE `to_id` = '" . So_Secure($_GET['user_id']) . "' AND `seen` = '0'");

header("Content-type: application/json");
echo json_encode($data, JSON_PRETTY_PRINT);
exit();
?>
