<?php
// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+
define('T_CONFIG', 'so_config');
define('T_USERS', 'so_users');
define('T_POSTS', 'so_posts');
define('T_HASHTAGS', 'so_hashtags');
define('T_EMOTICONS', 'so_emoticons');
define('T_LIKE', 'so_like');
define('T_NOTIFICATIONS', 'so_notifications');
define('T_COMMENTS', 'so_comments');
define('T_COMMENTS_LIKE', 'so_comments_like');
define('T_FOLLOWERS', 'so_followers');
define('T_MESSAGES', 'so_messages');
define('T_OPEN_CHATS', 'so_open_chats');
define('T_REACTIONS', 'so_reactions');
define('T_STICKERS_STORE', 'so_stickers_store');
define('T_STICKERS', 'so_stickers');
define('T_USER_STICKERS', 'so_user_stickers');
?>