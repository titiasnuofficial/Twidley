<?php
// +------------------------------------------------------------------------+
// | @author Titiasnu Official (titiasnu_official)
// | @author_url 1: https://www.twidley.com
// | @author_url 2: titiasnu1@gmail.com   
// +------------------------------------------------------------------------+
// | Twidley - The Pro Social Network
// | Copyright (c) 2018 Twidley. All rights reserved.
// +------------------------------------------------------------------------+
require 'resources/classes/phpmailer/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer;