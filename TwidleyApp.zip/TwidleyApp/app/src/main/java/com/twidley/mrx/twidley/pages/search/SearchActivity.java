package com.twidley.mrx.twidley.pages.search;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;

import com.twidley.mrx.twidley.MainActivity;
import com.twidley.mrx.twidley.R;
import com.twidley.mrx.twidley.pages.CustomWebViewClient;

import static com.twidley.mrx.twidley.Config.SITE_URL_DEFAULT;
import static com.twidley.mrx.twidley.MainActivity.EXTRA_SEARCH_INPUT;

public class SearchActivity extends AppCompatActivity {
    private WebView webViewSearch;
    private String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        SharedPreferences preferences = getSharedPreferences("users_preferences", MODE_PRIVATE);
        user_id = preferences.getString("user_id", null);

        Intent intent = getIntent();
        String searchValue = intent.getStringExtra(EXTRA_SEARCH_INPUT);

        CookieManager.getInstance().setAcceptCookie(true);
        webViewSearch = findViewById(R.id.webviewSearch);

        if (savedInstanceState != null) {
            // retaura o webview
            webViewSearch.restoreState(savedInstanceState);
        }

        webViewSearch.getSettings().setJavaScriptEnabled(true);
        webViewSearch.getSettings().setDomStorageEnabled(true);
        webViewSearch.setWebViewClient(new CustomWebViewClient());
        webViewSearch.loadUrl(SITE_URL_DEFAULT + "search-app?q=" + searchValue + "&session=" + user_id + "&connected_via=mobile");
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
