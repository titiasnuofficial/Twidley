package com.twidley.mrx.twidley.pages;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.MainActivity;
import com.twidley.mrx.twidley.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;

public class ForgotPasswordActivity extends AppCompatActivity {
    private TextView welcomeForgot;
    private AutoCompleteTextView email;
    private Button recoverForgot;
    private TextView resultForgot;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferences =
                getSharedPreferences("user_preferences", MODE_PRIVATE);

        if(preferences.contains("user_id")){
            openHomePage();
        }

        setContentView(R.layout.activity_forgot_password);

        welcomeForgot = findViewById(R.id.welcomeForgot);
        welcomeForgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginPage();
            }
        });

        recoverForgot = findViewById(R.id.recoverForgot);
        email = findViewById(R.id.emailForgot);
        resultForgot = findViewById(R.id.resultForgot);

        recoverForgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recoverPassword();
            }
        });

        mRequestQueue = Volley.newRequestQueue(this);

    }

    private void openHomePage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void recoverPassword() {
        String url = SITE_URL + "?type=password-reset&email=" + email.getText();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");
                                if (Integer.valueOf(status) == 200) {
                                    String message = getString(R.string.email_sended_check);
                                    resultForgot.setText(message);
                                } else if (Integer.valueOf(status) == 400) {
                                    String errors = jsonObject.getString("errors");
                                    Integer number = new Integer(errors);
                                    String message = "";
                                    if (number == 1) {
                                        message = getString(R.string.user_email_not_found);
                                    } else if (number == 3) {
                                        message = getString(R.string.error_to_send_email);
                                    } else if (number == 4) {
                                        message = getString(R.string.check_details);
                                    } else {
                                        return;
                                    }
                                    resultForgot.setText(message);
                                } else {
                                    resultForgot.setText(getString(R.string.not_found));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resultForgot.setText(getString(R.string.connect_error));
            }
        });

        mRequestQueue.add(request);
    }

    private void openLoginPage() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}
