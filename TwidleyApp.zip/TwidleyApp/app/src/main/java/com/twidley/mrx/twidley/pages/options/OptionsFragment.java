package com.twidley.mrx.twidley.pages.options;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.twidley.mrx.twidley.R;
import com.twidley.mrx.twidley.pages.LoginActivity;
import com.twidley.mrx.twidley.pages.SettingsActivity;
import com.twidley.mrx.twidley.pages.profile.ProfileFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import static android.content.Context.MODE_PRIVATE;
import static com.twidley.mrx.twidley.Config.SITE_URL;

public class OptionsFragment extends Fragment {
    private RequestQueue requestQueue;
    private TextView optionsLogout;
    private TextView optionsProfile;
    private TextView optionsSettings;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_options, container, false);

        optionsLogout = view.findViewById(R.id.optionsLogout);
        optionsLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences settings = getActivity().getSharedPreferences("user_preferences", Context.MODE_PRIVATE);
                settings.edit().clear().commit();
                openLogin();
            }
        });

        optionsProfile = view.findViewById(R.id.optionsProfile);
        optionsProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
            }
        });

        optionsSettings = view.findViewById(R.id.optionsSettings);
        optionsSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        });

        requestQueue = Volley.newRequestQueue(this.getActivity());

        jsonOptions();

        return view;
    }

    private void openSettings() {
        Intent intent = new Intent(this.getActivity(), SettingsActivity.class);
        startActivity(intent);
    }

    private void jsonOptions() {
        SharedPreferences preferences = this.getActivity().getSharedPreferences("user_preferences", MODE_PRIVATE);
        String user_id = preferences.getString("user_id", null);

        String url = SITE_URL + "?type=user-data&user_id=" + user_id;

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String name = jsonObject.getString("name");
                                String username = jsonObject.getString("username");
                                String avatar = jsonObject.getString("avatar");

                                TextView optionsName = getActivity().findViewById(R.id.optionsNameUser);
                                TextView optionsUsername = getActivity().findViewById(R.id.optionsUsername);
                                ImageView optionsUserAvatar = getActivity().findViewById(R.id.optionsUserAvatar);

                                optionsName.setText(name);
                                optionsUsername.setText("@" + username);

                                Picasso.get().load(avatar).into(optionsUserAvatar);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(request);
    }

    private void openLogin() {
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        startActivity(intent);
        getActivity().finish();
    }
}
