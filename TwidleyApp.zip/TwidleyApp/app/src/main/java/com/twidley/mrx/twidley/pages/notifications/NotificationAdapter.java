package com.twidley.mrx.twidley.pages.notifications;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.twidley.mrx.twidley.R;
import com.twidley.mrx.twidley.pages.CustomWebViewClient;

import java.util.ArrayList;

import static com.twidley.mrx.twidley.Config.SITE_URL_DEFAULT;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder> {
        private Context mContext;
        private ArrayList<Notification> mNotificationList;
        private OnItemClickListener mListener;

    public interface OnItemClickListener {
            void onItemClick(int position);
        }

    public void setOnItemClickListener(OnItemClickListener listener) {
            mListener = listener;
        }

    public NotificationAdapter(Context context, ArrayList<Notification> notifications) {
            mContext = context;
            mNotificationList = notifications;
        }

        @Override
        public NotificationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(mContext).inflate(R.layout.item_notification, parent, false);
            return new NotificationViewHolder(v);
        }

        @Override
        public void onBindViewHolder(NotificationViewHolder holder, int position) {
            Notification currentItem = mNotificationList.get(position);

            String imageUrl = currentItem.getAvatar();
            String notifiType = currentItem.getType();
            String notifiId = currentItem.getId();
            String notifiPostId = currentItem.getPost_id();
            String notifiCommentId = currentItem.getComment_id();
            String notifiNameUser = currentItem.getName();
            String notifiTime = currentItem.getTime();
            String notifiToId = currentItem.getTo_id();
            String notifiOriginalType = currentItem.getOriginal_type();

            holder.notificationId.setText(notifiId);
            holder.notificationType.setText(notifiType);
            holder.notificationPostId.setText(notifiPostId);
            holder.notificationCommentId.setText(notifiCommentId);
            holder.notificationNameUser.setText(notifiNameUser);
            holder.notificationTime.setText(notifiTime);
            holder.notificationOriginalType.setText(notifiOriginalType);

            holder.notificationWebView.getSettings().setJavaScriptEnabled(true);
            holder.notificationWebView.getSettings().setDomStorageEnabled(true);
            holder.notificationWebView.setWebViewClient(new CustomWebViewClient());
            holder.notificationWebView.loadUrl(SITE_URL_DEFAULT + "notifications-app?notifi_id=" + notifiId + "&user_id=" + notifiToId);

            Picasso.get().load(imageUrl).into(holder.notificationUserAvatar);
        }

        @Override
        public int getItemCount() {
            return mNotificationList.size();
        }

        public class NotificationViewHolder extends RecyclerView.ViewHolder {
            public ImageView notificationUserAvatar;
            public TextView notificationType;
            public TextView notificationId;
            public TextView notificationPostId;
            public TextView notificationCommentId;
            public TextView notificationNameUser;
            public TextView notificationTime;
            public WebView notificationWebView;
            public TextView notificationOriginalType;

            public NotificationViewHolder(View itemView) {
                super(itemView);
                notificationId = itemView.findViewById(R.id.notificationId);
                notificationPostId = itemView.findViewById(R.id.notificationPostId);
                notificationCommentId = itemView.findViewById(R.id.notificationCommentId);
                notificationUserAvatar = itemView.findViewById(R.id.notificationUserAvatar);
                notificationNameUser = itemView.findViewById(R.id.notificationNameUser);
                notificationType = itemView.findViewById(R.id.notificationType);
                notificationTime = itemView.findViewById(R.id.notificationTime);
                notificationWebView = itemView.findViewById(R.id.notificationWebView);
                notificationOriginalType = itemView.findViewById(R.id.notificationOriginalType);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mListener != null) {
                            int position = getAdapterPosition();
                            if (position != RecyclerView.NO_POSITION) {
                                mListener.onItemClick(position);
                            }
                        }
                    }
                });
            }
        }
}
