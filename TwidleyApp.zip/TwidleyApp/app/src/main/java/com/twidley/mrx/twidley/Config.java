package com.twidley.mrx.twidley;

public class Config {
    public static String SITE_URL = "https://www.twidley.com/requests_phone.php";
    public static String SITE_URL_DEFAULT = "https://www.twidley.com/";
    public static String VERIFICATION = "PURSHASE_CODE_APP";

}
