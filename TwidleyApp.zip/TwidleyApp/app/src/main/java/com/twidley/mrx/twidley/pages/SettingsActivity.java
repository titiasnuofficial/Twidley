package com.twidley.mrx.twidley.pages;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.support.design.widget.TextInputEditText;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.twidley.mrx.twidley.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;

public class SettingsActivity extends Activity {
    private String user_id;
    private RequestQueue requestQueue;

    private TextInputEditText usernameSetting;
    private TextInputEditText first_nameSetting;
    private TextInputEditText last_nameSetting;
    private TextInputEditText emailSetting;
    private TextInputEditText numberSetting;
    private TextInputEditText locationSetting;
    private TextInputEditText aboutSetting;

    private TextView resultSetting;

    private Button settingUpdateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        user_id = preferences.getString("user_id", null);

        resultSetting = findViewById(R.id.resultSetting);

        settingUpdateButton = findViewById(R.id.settingUpdateButton);
        settingUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonUpdateSettings();
            }
        });

        usernameSetting = findViewById(R.id.settingUsername);
        first_nameSetting = findViewById(R.id.settingFirstName);
        last_nameSetting = findViewById(R.id.settingLastName);
        emailSetting = findViewById(R.id.settingEmail);
        numberSetting = findViewById(R.id.settingNumber);
        locationSetting = findViewById(R.id.settingLocation);
        aboutSetting = findViewById(R.id.settingAbout);

        requestQueue = Volley.newRequestQueue(this);
        
        jsonGetUserData();

    }

    private void jsonUpdateSettings() {
        final String url = SITE_URL + "?type=update-general-settings" +
                "&user_id=" + user_id +
                "&username=" + usernameSetting.getText() +
                "&first_name=" + first_nameSetting.getText() +
                "&last_name=" + last_nameSetting.getText() +
                "&email=" + emailSetting.getText() +
                "&phone_number=" + numberSetting.getText() +
                "&location=" + locationSetting.getText() +
                "&about=" + aboutSetting.getText();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Log.d("url", url);
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");
                                if (Integer.valueOf(status) == 200) {
                                    resultSetting.setText(R.string.updated_success);
                                } else if (Integer.valueOf(status) == 400) {
                                    String errors = jsonObject.getString("errors");
                                    Integer number = new Integer(errors);
                                    String message = "";
                                    if (number == 1) {
                                        message = getString(R.string.check_details);
                                    } else if (number == 2) {
                                        message = getString(R.string.email_exist);
                                    } else if (number == 3) {
                                        message = getString(R.string.username_exist);
                                    } else if (number == 4) {
                                        message = getString(R.string.email_invalid);
                                    } else if (number == 5) {
                                        message = getString(R.string.username_characters_length);
                                    } else if (number == 6) {
                                        message = getString(R.string.username_invalid);
                                    } else if (number == 7) {
                                        message = getString(R.string.birthday_invalid);
                                    } else {
                                        return;
                                    }
                                    resultSetting.setText(message);
                                } else {
                                    resultSetting.setText(getString(R.string.not_found));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resultSetting.setText(getString(R.string.connect_error));
            }
        });

        // Add the request to the RequestQueue.
        requestQueue.add(request);
    }

    private void jsonGetUserData() {
        String url = SITE_URL + "?type=user-data&user_id=" + user_id;

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                usernameSetting.setText(jsonObject.getString("username"));
                                first_nameSetting.setText(jsonObject.getString("first_name"));
                                last_nameSetting.setText(jsonObject.getString("last_name"));
                                emailSetting.setText(jsonObject.getString("email"));

                                if (jsonObject.getString("location") != "") {
                                    locationSetting.setText(jsonObject.getString("location"));
                                }
                                if (jsonObject.getString("about") != "") {
                                    aboutSetting.setText(jsonObject.getString("about"));
                                }
                                if (jsonObject.getString("phone_number") != "") {
                                    numberSetting.setText(jsonObject.getString("phone_number"));
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(request);
    }

}
