package com.twidley.mrx.twidley.pages.profile;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.R;
import com.twidley.mrx.twidley.pages.CustomWebViewClient;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.content.ContentValues.TAG;
import static com.twidley.mrx.twidley.Config.SITE_URL_DEFAULT;
import static com.twidley.mrx.twidley.pages.notifications.NotificationActivity.EXTRA_USER_ID;

public class ProfileTwoActivity extends AppCompatActivity {
    private WebView webView;

    private String user_id;

    private ValueCallback<Uri[]> mFilePathCallback;
    private String diretorioFotoImagem;
    public static final int INPUT_FILE_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_two);

        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        user_id = preferences.getString("user_id", null);

        Intent intent = getIntent();
        String profile_id = intent.getStringExtra(EXTRA_USER_ID);

        CookieManager.getInstance().setAcceptCookie(true);
        webView = findViewById(R.id.webviewProfileTwo);

        // define as configurações basicas
        setWebview(webView);

        if (savedInstanceState != null) {
            // retaura o webview
            webView.restoreState(savedInstanceState);
        }

        webView.setWebChromeClient(new WebChromeClient() {
            public boolean onShowFileChooser(
                    WebView webView, ValueCallback<Uri[]> filePathCallback,
                    WebChromeClient.FileChooserParams fileChooserParams) {
                if(mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;

                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    // cria local onde a foto deve ir
                    File photoFile = null;
                    try {
                        photoFile = armazenarImagemTemp();
                        takePictureIntent.putExtra("PhotoPath", diretorioFotoImagem);
                    } catch (IOException ex) {
                        // Error occurred while creating the File
                        Log.e(TAG, "Unable to create Image File", ex);
                    }

                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                        diretorioFotoImagem = "file:" + photoFile.getAbsolutePath();
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(photoFile));
                    } else {
                        takePictureIntent = null;
                    }
                }

                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("image/*");

                Intent[] intentArray;
                if(takePictureIntent != null) {
                    intentArray = new Intent[]{takePictureIntent};
                } else {
                    intentArray = new Intent[0];
                }

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

                startActivityForResult(chooserIntent, INPUT_FILE_REQUEST_CODE);

                return true;
            }
        });

        webView.setWebViewClient(new CustomWebViewClient());

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        // carrega a URL
        if(webView.getUrl() == null) {
            webView.loadUrl(SITE_URL_DEFAULT + "t-app/" + profile_id + "?session=" + user_id + "&connected_via=mobile");
        }

    }

    @Override
    public void onActivityResult (int requestCode, int resultCode, Intent data) {
        if(requestCode != INPUT_FILE_REQUEST_CODE || mFilePathCallback == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }

        Uri[] results = null;

        // verifica se a resposta esta ok com a variável estática {RESULT_OK} do Activity
        if(resultCode == Activity.RESULT_OK) {
            if(data == null) {
                // se não houver dados solicitará que tire uma foto
                if(diretorioFotoImagem != null) {
                    results = new Uri[]{Uri.parse(diretorioFotoImagem)};
                }
            } else {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
        }

        mFilePathCallback.onReceiveValue(results);
        mFilePathCallback = null;
        return;
    }

    private File armazenarImagemTemp() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File imageFile = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        return imageFile;
    }
    private void setWebview(WebView webView) {
        WebSettings set = webView.getSettings();

        // habilita javascript
        set.setJavaScriptEnabled(true);

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            // oculta zoom no sdk HONEYCOMB+
            set.setDisplayZoomControls(false);
        }

        // habilita debugging remoto via chrome {inspect}
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        webView.setWebViewClient(new WebViewClient());
    }
}
