package com.twidley.mrx.twidley.pages;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.MainActivity;
import com.twidley.mrx.twidley.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;

public class LoginActivity extends AppCompatActivity {
    private AutoCompleteTextView email;
    private EditText password;
    private Button button_login;
    private TextView welcome;
    private TextView forgot_password;
    private TextView register_account;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferences =
                getSharedPreferences("user_preferences", MODE_PRIVATE);

        if(preferences.contains("user_id")){
            openHomePage();
        }

        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        welcome = findViewById(R.id.result);

        button_login = findViewById(R.id.email_sign_in_button);

        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });

        forgot_password = findViewById(R.id.forgot_password);
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openForgotPassword();
            }
        });

        register_account = findViewById(R.id.register);
        register_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegisterAccount();
            }
        });

        mRequestQueue = Volley.newRequestQueue(this);
    }

    private void openRegisterAccount() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
        finish();
    }

    private void openForgotPassword() {
        Intent intent = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent);
        finish();
    }

    public void signIn() {
        String url = SITE_URL + "?type=signin&email=" + email.getText() + "&password=" + password.getText();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");
                                if (Integer.valueOf(status) == 200) {

                                    String user_id = jsonObject.getString("user_id");
                                    SharedPreferences settings = getSharedPreferences("user_preferences", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = settings.edit();
                                    editor.putString("user_id", user_id);
                                    editor.commit();

                                    openHomePage();

                                } else if (Integer.valueOf(status) == 400) {
                                    String errors = jsonObject.getString("errors");
                                    Integer number = new Integer(errors);
                                    String message = "";
                                    if (number == 1) {
                                        message = getString(R.string.user_not_found);
                                    } else if (number == 2) {
                                        message = getString(R.string.error_on_signin);
                                    } else if (number == 3) {
                                        message = getString(R.string.check_details);
                                    } else {
                                        return;
                                    }
                                    welcome.setText(message);
                                } else {
                                    welcome.setText(getString(R.string.not_found));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                welcome.setText(getString(R.string.connect_error));
            }
        });

        // Add the request to the RequestQueue.
        mRequestQueue.add(request);
    }

    private void openHomePage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
