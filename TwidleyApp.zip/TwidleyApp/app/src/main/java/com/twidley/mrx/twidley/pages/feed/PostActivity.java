package com.twidley.mrx.twidley.pages.feed;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.TextView;

import com.twidley.mrx.twidley.R;
import com.twidley.mrx.twidley.pages.CustomWebViewClient;

import static com.twidley.mrx.twidley.pages.notifications.NotificationActivity.NOTI_URL;
import static com.twidley.mrx.twidley.pages.notifications.NotificationActivity.TITLE_NOTIFICATION;

public class PostActivity extends Activity {
    private WebView webView;
    private TextView postTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        Intent intent = getIntent();
        String title = intent.getStringExtra(TITLE_NOTIFICATION);
        final String url = intent.getStringExtra(NOTI_URL);

        CookieManager.getInstance().setAcceptCookie(true);
        webView = findViewById(R.id.webviewPost);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new CustomWebViewClient());
        webView.loadUrl(url);

        postTitle = findViewById(R.id.postTitle);
        postTitle.setText(title);
    }

}
