package com.twidley.mrx.twidley;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.pages.notifications.NotificationActivity;
import com.twidley.mrx.twidley.pages.options.OptionsFragment;
import com.twidley.mrx.twidley.pages.feed.FeedFragment;
import com.twidley.mrx.twidley.pages.search.SearchActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;

public class MainActivity extends AppCompatActivity {
    private RequestQueue requestQueue;
    private EditText searchInput;
    public static final String EXTRA_SEARCH_INPUT = "q";

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (requestRecordCameraPermission()) {
            requestRecordAudioPermission();
        }

        requestQueue = Volley.newRequestQueue(this);

        searchInput = findViewById(R.id.searchInput);
        searchInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                onRestart();

                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    searchUsers(searchInput.getText().toString());
                }
                return true;
            }
        });

        getCountNotifications();

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        if (savedInstanceState == null) {
            // retaura o webview
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new FeedFragment()).commit();
        }

    }

    private void searchUsers(String search) {
        if (!search.isEmpty()) {
            Intent intent = new Intent(this, SearchActivity.class);
            intent.putExtra(EXTRA_SEARCH_INPUT, search);
            startActivity(intent);
        } else {
            return;
        }
    }

    private void getCountNotifications() {
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        String user_id = preferences.getString("user_id", null);

        final String url = SITE_URL + "?type=get-notifications-count&user_id=" + user_id;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                String total = jsonObject.getString("total");
                                if (Integer.valueOf(total) != 0) {
                                    BottomNavigationItemView itemView = findViewById(R.id.nav_notification);
                                    itemView.setTitle(total);
                                    itemView.setTextColor(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                                } else {
                                    BottomNavigationItemView itemView = findViewById(R.id.nav_notification);
                                    itemView.setTitle("");
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(request);

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        getCountNotifications();
                    }
                },
                5000);

    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    if (menuItem.getItemId() == R.id.nav_notification) {
                        openNotifications();
                    } else {
                        Fragment selectedFragment = null;

                        switch (menuItem.getItemId()) {
                            case R.id.nav_home:
                                findViewById(R.id.bottom_search).setVisibility(View.VISIBLE);
                                selectedFragment = new FeedFragment();
                                break;
                            case R.id.nav_options:
                                findViewById(R.id.bottom_search).setVisibility(View.GONE);
                                selectedFragment = new OptionsFragment();
                                break;
                        }

                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                selectedFragment).commit();

                    }
                    return true;
                }
            };

    private void openNotifications() {
        Intent intent = new Intent(this, NotificationActivity.class);
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void requestRecordAudioPermission() {

        String requiredPermission = Manifest.permission.RECORD_AUDIO;

        // If the user previously denied this permission then show a message explaining why
        // this permission is needed
        if (checkCallingOrSelfPermission(requiredPermission) == PackageManager.PERMISSION_GRANTED) {

        } else {

            Toast.makeText(this, "This app needs to record audio through the microphone....", Toast.LENGTH_SHORT).show();
            requestPermissions(new String[]{requiredPermission}, 101);
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean requestRecordCameraPermission() {

        String requiredPermission = Manifest.permission.CAMERA;

        // If the user previously denied this permission then show a message explaining why
        // this permission is needed
        if (checkCallingOrSelfPermission(requiredPermission) == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {

            Toast.makeText(this, "This app needs to record camera video....", Toast.LENGTH_SHORT).show();
            requestPermissions(new String[]{requiredPermission}, 101);
            return false;
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        if (requestCode == 101 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // This method is called when the  permissions are given
        }

    }
}
