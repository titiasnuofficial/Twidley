package com.twidley.mrx.twidley.pages.notifications;

public class Notification {
    private String id;
    private String comment_id;
    private String post_id;
    private String user_id;
    private String to_id;
    private String type;
    private String time;
    private String day;
    private String month;
    private String year;
    private String seen;
    private String avatar;
    private String name;
    private String comment;
    private String original_type;

    public Notification(String id, String comment_id, String post_id, String user_id, String to_id, String type, String time, String day, String month, String year, String seen, String avatar, String name, String comment, String original_type) {
        this.id = id;
        this.comment_id = comment_id;
        this.post_id = post_id;
        this.user_id = user_id;
        this.to_id = to_id;
        this.type = type;
        this.time = time;
        this.day = day;
        this.month = month;
        this.year = year;
        this.seen = seen;
        this.avatar = avatar;
        this.name = name;
        this.comment = comment;
        this.original_type = original_type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComment_id() {
        return comment_id;
    }

    public void setComment_id(String comment_id) {
        this.comment_id = comment_id;
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTo_id() {
        return to_id;
    }

    public void setTo_id(String to_id) {
        this.to_id = to_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSeen() {
        return seen;
    }

    public void setSeen(String seen) {
        this.seen = seen;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getOriginal_type() {
        return original_type;
    }

    public void setOriginal_type(String original_type) {
        this.original_type = original_type;
    }
}
