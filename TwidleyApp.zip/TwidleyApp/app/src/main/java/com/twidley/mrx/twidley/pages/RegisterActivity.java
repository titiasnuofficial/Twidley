package com.twidley.mrx.twidley.pages;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.MainActivity;
import com.twidley.mrx.twidley.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;

public class RegisterActivity extends AppCompatActivity {
    private TextView welcomeRegister;
    private TextView resultRegister;
    private AutoCompleteTextView emailRegister;
    private EditText passwordRegister;
    private EditText usernameRegister;
    private EditText first_nameRegister;
    private EditText last_nameRegister;
    private Button sign_up_button;

    private RequestQueue requestQueue;
    private RequestQueue mrequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferences =
                getSharedPreferences("user_preferences", MODE_PRIVATE);

        if(preferences.contains("user_id")){
            openHomePage();
        }

        setContentView(R.layout.activity_register);

        welcomeRegister = findViewById(R.id.welcomeRegister);
        welcomeRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin();
            }
        });

        emailRegister = findViewById(R.id.emailRegister);
        passwordRegister = findViewById(R.id.passwordRegister);
        usernameRegister = findViewById(R.id.usernameRegister);
        first_nameRegister = findViewById(R.id.first_nameRegister);
        last_nameRegister = findViewById(R.id.last_nameRegister);

        resultRegister = findViewById(R.id.resultRegister);

        sign_up_button = findViewById(R.id.sign_up_button);
        sign_up_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        requestQueue = Volley.newRequestQueue(this);
        mrequestQueue = Volley.newRequestQueue(this);
    }

    private void openHomePage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void registerUser() {
        String url = SITE_URL + "?type=signup&username=" + usernameRegister.getText()
                + "&first_name=" + first_nameRegister.getText()
                + "&last_name=" + last_nameRegister.getText()
                + "&email=" + emailRegister.getText()
                + "&password=" + passwordRegister.getText();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");

                                if (Integer.valueOf(status) == 200) {

                                    String user_id = jsonObject.getString("user_id");

                                    SharedPreferences.Editor editor = getSharedPreferences("user_preferences", MODE_PRIVATE).edit();
                                    editor.putString("user_id", user_id);
                                    editor.commit();

                                    openUploadAfterRegister();

                                } else if (Integer.valueOf(status) == 400) {

                                    String errors = jsonObject.getString("errors");
                                    Integer number = new Integer(errors);
                                    String message = "";

                                    if (number == 1) {
                                        message = getString(R.string.email_exist);
                                    } else if (number == 2) {
                                        message = getString(R.string.username_exist);
                                    } else if (number == 3) {
                                        message = getString(R.string.error_on_signup);
                                    } else if (number == 4) {
                                        message = getString(R.string.check_details);
                                    } else {
                                        return;
                                    }
                                    resultRegister.setText(message);

                                } else {
                                    resultRegister.setText(getString(R.string.not_found));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resultRegister.setText(getString(R.string.connect_error));
            }
        });

        requestQueue.add(request);
    }

    private void openUploadAfterRegister() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void openLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
