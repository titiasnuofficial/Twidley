package com.twidley.mrx.twidley.pages;

import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.twidley.mrx.twidley.R;

public class CustomWebViewClient extends WebViewClient {
    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        super.onReceivedError(view, errorCode, description, failingUrl);
        view.loadUrl("file:///android_asset/error.html");
    }
}
