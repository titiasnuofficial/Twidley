package com.twidley.mrx.twidley.pages;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.twidley.mrx.twidley.MainActivity;
import com.twidley.mrx.twidley.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.twidley.mrx.twidley.Config.SITE_URL;
import static com.twidley.mrx.twidley.Config.VERIFICATION;

public class SplashScreen extends AppCompatActivity {
    private RequestQueue requestQueue;
    private String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        requestQueue = Volley.newRequestQueue(this);

        codeP();
    }

    private void codeP() {
        String url = SITE_URL + "?type=check-app&code=" + VERIFICATION;

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");
                                if (Integer.valueOf(status) == 400) {
                                    CloseApp();
                                } else {
                                    SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
                                    if (preferences.contains("user_id")) {
                                        user_id = preferences.getString("user_id", null);
                                        checkLoggedin(user_id);
                                    } else {
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                openLogin();
                                            }
                                        }, 2000);
                                    }
                                }
                            }
                        } catch (JSONException e) {
                            CloseApp();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                CloseApp();
            }
        });

        requestQueue.add(request);
    }

    private void CloseApp() {
        this.finishAffinity();
    }

    private void checkLoggedin(String user_id) {
        String url = SITE_URL + "?type=check-loggedin&user_id=" + user_id;

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String status = jsonObject.getString("status");
                                if (Integer.valueOf(status) == 200) {
                                    openHome();
                                } else {

                                    SharedPreferences.Editor editor = getSharedPreferences("user_preferences", MODE_PRIVATE).edit();
                                    editor.putString("user_id", null);
                                    editor.commit();

                                    openLogin();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(request);
    }

    private void openHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void openLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
